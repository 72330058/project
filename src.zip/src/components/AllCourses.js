import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import web from "../assets/images/web.jpg";
import digital from "../assets/images/digital.jpg";
import social from "../assets/images/social.jpg";
import mngmnt from "../assets/images/mngmnt.jpg";
import creative from "../assets/images/creative.jpg";
import machine from "../assets/images/machine.jpg";
import blockchain from "../assets/images/blockchain.jpg";
import executive from "../assets/images/executive.jpg";
import python from "../assets/images/python.jpg";
import figma from "../assets/images/figma.jpg";
import reactImage from "../assets/images/react.jpg";
import advanced from "../assets/images/advanced.jpg";
import "../assets/styles/allcourses.css";
import TrialPlansModal from "../components/TrialPlansModal";
import SubscriptionModal from "../components/SubscriptionModal";

const courseSections = [
  {
    title: "Free Courses",
    color: "#00d26a",
    courses: [
      {
        category: "Development",
        title: "Introduction to Web Development 2025",
        instructor: "Sarah Smith",
        rating: 4.8,
        lessons: 12,
        duration: "6h 30m",
        price: "Free",
        button: "Enroll Now",
        image: web,
      },
      {
        category: "Marketing",
        title: "Digital Marketing Basics",
        instructor: "John Doe",
        rating: 4.8,
        lessons: 12,
        duration: "6h 30m",
        price: "Free",
        button: "Enroll Now",
        image: digital,
      },
      {
        category: "Design",
        title: "Figma for Beginners",
        instructor: "Emily Chen",
        rating: 4.9,
        lessons: 12,
        duration: "6h 30m",
        price: "Free",
        button: "Enroll Now",
        image: figma,
      },
    ],
  },

  {
    title: "Start with a Free Trial",
    color: "#3b82f6",
    courses: [
      {
        category: "Development",
        title: "Full Stack React Masterclass",
        instructor: "David Wilson",
        rating: 4.9,
        lessons: 12,
        duration: "6h 30m",
        price: "$89",
        button: "Start Trial",
        tag: "7-Day Free Trial",
        image: reactImage,
      },
      {
        category: "Design",
        title: "Advanced UI/UX Design Patterns",
        instructor: "Lisa Anderson",
        rating: 4.8,
        lessons: 12,
        duration: "6h 30m",
        price: "$75",
        button: "Start Trial",
        tag: "7-Day Free Trial",
        image: advanced,
      },
      {
        category: "Business",
        title: "Project Management Professional",
        instructor: "Robert Brown",
        rating: 4.7,
        lessons: 12,
        duration: "6h 30m",
        price: "$95",
        button: "Start Trial",
        tag: "7-Day Free Trial",
        image: mngmnt,
      },
    ],
  },

  {
    title: "Best Value (Under $50)",
    color: "#a855f7",
    courses: [
      {
        category: "Data Science",
        title: "Python for Data Science",
        instructor: "Michael Lee",
        rating: 4.7,
        lessons: 12,
        duration: "6h 30m",
        price: "$49",
        button: "Buy Now",
        image: python,
      },
      {
        category: "Arts",
        title: "Creative Writing Workshop",
        instructor: "Jessica Taylor",
        rating: 4.8,
        lessons: 12,
        duration: "6h 30m",
        price: "$45",
        button: "Buy Now",
        image: creative,
      },
      {
        category: "Marketing",
        title: "Social Media Strategy",
        instructor: "Alex Johnson",
        rating: 4.6,
        lessons: 12,
        duration: "6h 30m",
        price: "$55",
        button: "Buy Now",
        image: social,
      },
    ],
  },

  {
    title: "Advanced Masterclasses ($100+)",
    color: "#f97316",
    courses: [
      {
        category: "AI & ML",
        title: "Machine Learning A-Z™️",
        instructor: "Dr. Ryan Cooper",
        rating: 4.9,
        lessons: 12,
        duration: "6h 30m",
        price: "$129",
        button: "Buy Now",
        image: machine,
      },
      {
        category: "Development",
        title: "Blockchain Development Bootcamp",
        instructor: "Chris Martin",
        rating: 4.8,
        lessons: 12,
        duration: "6h 30m",
        price: "$149",
        button: "Buy Now",
        image: blockchain,
      },
      {
        category: "Business",
        title: "Executive Leadership Program",
        instructor: "Amanda White",
        rating: 4.9,
        lessons: 12,
        duration: "6h 30m",
        price: "$199",
        button: "Buy Now",
        image: executive,
      },
    ],
  },
];

const AllCourses = () => {
  const navigate = useNavigate();

  const [showPlansModal, setShowPlansModal] = useState(false);
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);

  const handleCourseClick = (course) => {
    if (course.button === "Start Trial") {
      setShowPlansModal(true);
      return;
    }

    if (course.button === "Enroll Now" || course.price === "Free") {
      navigate("/enroll", { state: course });
      return;
    }

    navigate("/checkout", { state: course });
  };

  return (
    <>
      <div className="popular-courses-wrapper">
        {courseSections.map((section, i) => (
          <section key={i} className="course-section">
            <div className="section-header">
              <div className="title-group">
                <span
                  className="section-indicator"
                  style={{ background: section.color }}
                ></span>
                <h2>{section.title}</h2>
              </div>
            </div>

            <div className="course-grid">
              {section.courses.map((course, index) => (
                <div className="course-card" key={index}>
                  <div
                    className="card-image"
                    style={{ backgroundImage: `url(${course.image})` }}
                  >
                    {course.tag && <span className="badge">{course.tag}</span>}
                  </div>

                  <div className="card-content">
                    <span className="category">{course.category}</span>
                    <h3 className="card-title">{course.title}</h3>
                    <p className="instructor">{course.instructor}</p>

                    <div className="details-row">
                      <span>⭐ {course.rating}</span>
                      <span>{course.lessons} Lessons</span>
                      <span>{course.duration}</span>
                    </div>

                    <div className="price-row">
                      <span className="price">{course.price}</span>
                      <button
                        className="buy-btn"
                        onClick={() => handleCourseClick(course)}
                      >
                        {course.button}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        ))}
      </div>

      <TrialPlansModal
        open={showPlansModal}
        onClose={() => setShowPlansModal(false)}
        setOpenSubscription={setShowSubscriptionModal}
      />

      <SubscriptionModal
        open={showSubscriptionModal}
        onClose={() => setShowSubscriptionModal(false)}
      />
    </>
  );
};

export default AllCourses;
