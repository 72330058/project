import React from "react";

const StatsSection = () => {
  return (
    <section className="stats-wrapper">
      <div className="container stats-row">
        <div className="stat-item">
          <div className="stat-value">50,000+</div>
          <div className="stat-label">Active Students</div>
        </div>
        <div className="stat-item">
          <div className="stat-value">1,200+</div>
          <div className="stat-label">Expert Courses</div>
        </div>
        <div className="stat-item">
          <div className="stat-value">500+</div>
          <div className="stat-label">Qualified Instructors</div>
        </div>
        <div className="stat-item">
          <div className="stat-value">95%</div>
          <div className="stat-label">Success Rate</div>
        </div>
      </div>
    </section>
  );
}

export default StatsSection;