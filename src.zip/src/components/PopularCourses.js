import React from "react";
import CourseCard from "./CourseCard";
import webdevImg from "../assets/images/course-webdev.jpg";
import dsImg from "../assets/images/course-datascience.jpg";
import marketingImg from "../assets/images/course-marketing.jpg";
import uiuxImg from "../assets/images/course-uiux.jpg";
import mlImg from "../assets/images/course-ml.jpg";
import businessImg from "../assets/images/course-business.jpg";
import { useNavigate } from "react-router-dom";

const PopularCourses = () => {
  const navigate =useNavigate();
  const handleViewCourses =() =>{
    navigate("/courses");
  };
  const courses = [
    {
      image: webdevImg,
      category: "Development",
      title: "Web Development Fundamentals",
      instructor: "by Sarah Johnson",
      rating: "4.8",
      students: "76,243",
      duration: "8 weeks",
      level: "Beginner",
    },
    {
      image: dsImg,
      category: "Data Science",
      title: "Data Science with Python",
      instructor: "by Michael Chen",
      rating: "4.9",
      students: "68,902",
      duration: "10 weeks",
      level: "Intermediate",
    },
    {
      image: marketingImg,
      category: "Marketing",
      title: "Digital Marketing Mastery",
      instructor: "by Emily Rodriguez",
      rating: "4.8",
      students: "75,234",
      duration: "6 weeks",
      level: "Beginner",
    },
    {
      image: uiuxImg,
      category: "Design",
      title: "UI/UX Design Principles",
      instructor: "by David Kim",
      rating: "4.7",
      students: "41,067",
      duration: "7 weeks",
      level: "Intermediate",
    },
    {
      image: mlImg,
      category: "AI & ML",
      title: "Machine Learning Basics",
      instructor: "by Dr. Amanda White",
      rating: "4.8",
      students: "43,012",
      duration: "12 weeks",
      level: "Advanced",
    },
    {
      image: businessImg,
      category: "Business",
      title: "Business Strategy & Leadership",
      instructor: "by James Wilson",
      rating: "4.7",
      students: "39,845",
      duration: "8 weeks",
      level: "Intermediate",
    },
  ];

  return (
    <section className="popular-courses-section">
      <div className="container">
        <div className="section-header">
          <div>
            <h2>Popular Courses</h2>
            <p>
              Explore our most popular courses taught by industry experts.
            </p>
          </div>
          <button
            className="btn btn-outline-small"
            onClick={handleViewCourses}>
            View All Courses
          </button>
        </div>

        <div className="course-grid">
          {courses.map((course) => (
            <div className="course-card" key={course.title}>
            <CourseCard key={course.title} {...course} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default PopularCourses;