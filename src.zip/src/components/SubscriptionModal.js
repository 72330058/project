import React from "react";
import subscription from "../assets/styles/subscription.css";

import CloseIcon from "@mui/icons-material/Close";
import CreditCardIcon from "@mui/icons-material/CreditCard";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";

const SubscriptionModal = ({ open, onClose }) => {
  if (!open) return null;

  return (
    <div className="sub-overlay">
      <div className="sub-modal sub-light">

        <button className="sub-close-light" onClick={onClose}>
          <CloseIcon style={{ fontSize: 22 }} />
        </button>

        <h2 className="sub-title-light">Subscription Management</h2>
        <p className="sub-subtitle-light">
          Manage your current plan and billing details.
        </p>

        <div className="sub-card-light">
          <div className="sub-plan-header-light">
            <h3>Pro Plan (Trial)</h3>
            <span className="sub-active-badge-light">Active</span>
          </div>

          <p className="sub-label-light">Trial Progress</p>

          <div className="sub-progress-light">
            <div
              className="sub-progress-fill-light"
              style={{ width: "14%" }}
            ></div>
          </div>

          <p className="sub-end-date-light">
            Your trial ends on <strong>November 29, 2025</strong>.
          </p>
        </div>

        <h3 className="sub-section-title-light">Billing Details</h3>

        <div className="sub-row-light">
          <div className="sub-icon-box-light">
            <CreditCardIcon style={{ fontSize: 22 }} />
          </div>

          <div className="sub-info-light">
            <p className="sub-row-title-light">Visa ending in 4242</p>
            <p className="sub-muted-light">Expires 12/28</p>
          </div>

          <button className="sub-edit-light">Edit</button>
        </div>

        <div className="sub-row-light">
          <div className="sub-icon-box-light">
            <CalendarMonthIcon style={{ fontSize: 22 }} />
          </div>

          <div className="sub-info-light">
            <p className="sub-row-title-light">Next Payment</p>
            <p className="sub-muted-light">$29.00 on Nov 30, 2025</p>
          </div>
        </div>

        <button className="sub-cancel-btn-light">Cancel Trial</button>

        <button className="sub-done-btn-light" onClick={onClose}>
          Done
        </button>
      </div>
    </div>
  );
};

export default SubscriptionModal;
