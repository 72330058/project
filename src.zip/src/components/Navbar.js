import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import MobileMenu from "./MobileMenu";
import logo from "../assets/images/logo.jpg.png";

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogoClick = () => {
    navigate("/");
  };

  const handleLoginClick = () => {
    navigate("/login");
  };

  const handleGetStartedClick = () => {
    navigate("/get-started");
  };

  return (
    <>
      <header className="navbar">
        <div className="container navbar-inner">
          <div className="navbar-left" onClick={handleLogoClick}>
            <img src={logo} alt="LearnHub logo" className="navbar-logo" />
          </div>

          <nav className="navbar-links">
            <Link to="/courses">Courses</Link>
            <Link to="/features">Features</Link>
            <Link to="/contact">Contact</Link>
          </nav>

          <div className="navbar-actions">
            <button className="btn btn-ghost" onClick={handleLoginClick}>
              Log in
            </button>
            <button className="btn btn-primary" onClick={handleGetStartedClick}>
              Get Started
            </button>
          </div>

          <button
            className="navbar-burger"
            onClick={() => setIsMenuOpen(true)}
            aria-label="Open menu"
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </header>
      
      {isMenuOpen && <MobileMenu onClose={() => setIsMenuOpen(false)} />}
    </>
  );
}

export default Navbar;