import React from "react";
import { Link, useNavigate } from "react-router-dom";

const MobileMenu = ({ onClose }) =>{
  const navigate = useNavigate();

  const handleLogin = () => {
    navigate("/login");
    onClose();
  };

  const handleGetStarted = () => {
    navigate("/get-started");
    onClose();
  };

  return (
    <div className="mobile-menu-overlay">
      <div className="mobile-menu">
        <div className="mobile-menu-header">
          <span className="navbar-brand">LearnHub</span>
          <button className="mobile-menu-close" onClick={onClose}>
            ✕
          </button>
        </div>

        <nav className="mobile-menu-links">
          <Link to="/courses" onClick={onClose}>
            Courses
          </Link>
          <Link to="/features" onClick={onClose}>
            Features
          </Link>
          <Link to="/Contact" onClick={onClose}>
            Contact
          </Link>
        </nav>

        <div className="mobile-menu-actions">
          <button className="btn btn-ghost full-width" onClick={handleLogin}>
            Log in
          </button>
          <button
            className="btn btn-primary full-width"
            onClick={handleGetStarted}
          >
            Get Started
          </button>
        </div>
      </div>
    </div>
  );
}

export default MobileMenu;