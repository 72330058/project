import React from "react";
import { HashRouter, Routes, Route } from "react-router-dom";

import Home from "../pages/Home";
import Courses from "../pages/Courses";
import Features from "../pages/Features";
import Contact from "../pages/Contact";
import Login from "../pages/Login";
import GetStarted from "../pages/GetStarted";
import CourseEnroll from "../pages/CourseEnroll";
import CourseCheckout from "../pages/CourseCheckout";
import ScrollToTop from "../components/ScrollToTop";

const AppRoutes = () => {
  return (
    <HashRouter>
      <ScrollToTop /> 
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/courses" element={<Courses />} />
        <Route path="/features" element={<Features />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/login" element={<Login />} />
        <Route path="/get-started" element={<GetStarted />} />
        <Route path="/enroll" element={<CourseEnroll />} />
        <Route path="/checkout" element={<CourseCheckout />} />
      </Routes>
    </HashRouter>
  );
};

export default AppRoutes;
