import React from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

const GetStarted = () => {
  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Get started action");
  };

  return (
    <>
      <Navbar />
      <main>
        <section className="page-header">
          <div className="container">
            <h1>Get Started</h1>
            <p>Create your free account and begin learning today.</p>
          </div>
        </section>

        <section className="container form-card-wrapper">
          <form className="form-card" onSubmit={handleSubmit}>
            <label>
              Name
              <input type="text" required placeholder="Your name" />
            </label>

            <label>
              Email
              <input type="email" required placeholder="you@example.com" />
            </label>

            <label>
              Password
              <input type="password" required placeholder="Create a password" />
            </label>

            <button className="btn btn-primary full-width" type="submit">
              Create Account
            </button>
          </form>
        </section>
      </main>
      <Footer />
    </>
  );
};

export default GetStarted;

