import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import CloseIcon from "@mui/icons-material/Close";
import "../assets/styles/enroll.css";

const CourseEnroll = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const course = location.state;

  if (!course) {
    return (
      <>
        <Navbar />
        <div className="enroll-wrapper">
          <h2 style={{ color: "red", textAlign: "center", marginTop: "30px" }}>
            Error: No course data received.
          </h2>
          <button
            onClick={() => navigate("/courses")}
            className="enroll-btn"
            style={{ marginTop: "20px" }}
          >
            Go Back to Courses
          </button>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Navbar />
      <div className="enroll-wrapper">
        <button
          className="close-enroll-btn"
          onClick={() => navigate("/courses")}
        >
          <CloseIcon />
        </button>
        <div className="enroll-left">
          <h1>{course.title}</h1>

          <p className="enroll-sub">
            Become skilled with this full training course.
          </p>

          <div className="enroll-instructor">
            <strong>Created by:</strong> {course.instructor}
          </div>

          <ul className="enroll-list">
            <li>✔ Full course access</li>
            <li>✔ Certificate included</li>
            <li>✔ Access on all devices</li>
            <li>✔ Lifetime access</li>
          </ul>
        </div>

        <div className="enroll-right">
          <div className="price-box">
            <h2 className="free-price">
              {course.price ? course.price : "Free"}
            </h2>

            <button className="enroll-btn">Enroll Now</button>

            <ul className="feature-list">
              <li>42.5 hours on-demand</li>
              <li>12 articles</li>
              <li>45 downloads</li>
              <li>Certificate of completion</li>
            </ul>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default CourseEnroll;
