import React from "react";
import Navbar from "../components/Navbar";
import AllCourses from "../components/AllCourses";
import Footer from "../components/Footer";

const Courses = () => {
  return (
    <>
      <Navbar />
      <main>
        <section className="page-header">
          <div className="container">
            <h1>Browse Courses</h1>
            <p>
              Discover courses across development, data science, design,
              business and more.
            </p>
          </div>
        </section>

        <AllCourses />
      </main>
      <Footer />
    </>
  );
};

export default Courses;
