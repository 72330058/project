import React, { useState } from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

  const Login = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loggedIn, setLoggedIn] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();

    if (username === "username" && password === "password") {
      alert("Successful login!");
      setLoggedIn(true);
    } else {
      alert("Unsuccessful login, try again.");
      setLoggedIn(false);
    }
  };

  const handleLogout = () => {
    setLoggedIn(false);
    setUsername("");
    setPassword("");
    alert("Logged out!");
  };

  return (
    <>
      <Navbar />
      <main>
        <section className="page-header">
          <div className="container">
            <h1>{loggedIn ? "Welcome!" : "Log in"}</h1>
            <p>
              {loggedIn
                ? "You are now logged in."
                : "Welcome back! Continue your learning journey."}
            </p>
          </div>
        </section>

        <section className="container form-card-wrapper">
          {!loggedIn ? (
            <form className="form-card" onSubmit={handleSubmit}>
              <label>
                Username
                <input
                  type="text"
                  required
                  placeholder="Enter username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                />
              </label>

              <label>
                Password
                <input
                  type="password"
                  required
                  placeholder="Enter password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </label>

              <button className="btn btn-primary full-width" type="submit">
                Log in
              </button>
            </form>
          ) : (
            <div className="form-card">
              <h3>You're logged in!</h3>

              <button
                className="btn btn-outline full-width"
                onClick={handleLogout}
              >
                Logout
              </button>
            </div>
          )}
        </section>
      </main>
      <Footer />
    </>
  );
};

export default Login;
