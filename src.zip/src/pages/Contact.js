import React, { useState } from "react";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import EmailOutlinedIcon from "@mui/icons-material/EmailOutlined";
import PhoneOutlinedIcon from "@mui/icons-material/PhoneOutlined";
import LocationOnOutlinedIcon from "@mui/icons-material/LocationOnOutlined";
import AccessTimeOutlinedIcon from "@mui/icons-material/AccessTimeOutlined";

const Contact = () => {
  const [success, setSuccess] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();          
    e.target.reset();          
    setSuccess("Your message has been sent! We will get back to you soon.");

    setTimeout(() => {
      setSuccess("");           
    }, 5000);
  };

  return (
    <div className="contact-wrapper">
      <div className="contact-container">
        <Navbar />

        <div className="contact-left">
          <h2>Send us a message</h2>
          <p>Fill out the form below and our team will get back to you within 24 hours.</p>

          {success && <p className="success-msg">{success}</p>}

          <form className="contact-form" onSubmit={handleSubmit}>
            <div className="row">
              <div className="input-group">
                <label>First Name</label>
                <input type="text" placeholder="Enter your first name" required />
              </div>
              <div className="input-group">
                <label>Last Name</label>
                <input type="text" placeholder="Enter your last name" required />
              </div>
            </div>

            <div className="input-group">
              <label>Email</label>
              <input type="email" placeholder="Enter your email" required />
            </div>

            <div className="input-group">
              <label>Subject</label>
              <select required>
                <option value="">Select a topic</option>
                <option value="course-enquiry">Course Enquiry</option>
                <option value="technical-support">Technical Support</option>
                <option value="account-issues">Account Issues</option>
                <option value="payment-questions">Payment / Billing</option>
                <option value="feedback">Feedback / Suggestions</option>
                <option value="partnership">Partnership / Collaboration</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div className="input-group">
              <label>Message</label>
              <textarea placeholder="Tell us more about your inquiry..." required></textarea>
            </div>

            <button type="submit" className="send-btn">Send Message</button>
          </form>
        </div>

        <div className="contact-right">
          <h2>Contact Information</h2>

          <div className="info-box">
            <div className="icon-wrapper">
              <EmailOutlinedIcon />
            </div>
            <div>
              <h4>Email</h4>
              <p>support@learnhub.com</p>
              <small>We’ll respond within 24 hours</small>
            </div>
          </div>

          <div className="info-box">
            <div className="icon-wrapper">
              <PhoneOutlinedIcon />
            </div>
            <div>
              <h4>Phone</h4>
              <p>+1 (555) 123-4567</p>
              <small>Mon–Fri, 9am–6pm EST</small>
            </div>
          </div>

          <div className="info-box">
            <div className="icon-wrapper">
              <LocationOnOutlinedIcon />
            </div>
            <div>
              <h4>Office</h4>
              <p>123 Learning Street</p>
              <small>San Francisco, CA 94102</small>
            </div>
          </div>

          <div className="info-box">
            <div className="icon-wrapper">
              <AccessTimeOutlinedIcon />
            </div>
            <div>
              <h4>Support Hours</h4>
              <p>Monday - Friday</p>
              <small>9:00 AM - 6:00 PM EST</small>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Contact;
